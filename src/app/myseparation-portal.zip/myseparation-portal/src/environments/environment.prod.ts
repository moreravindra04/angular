export const environment = {
  production: true,
  authProvider: ''
};
