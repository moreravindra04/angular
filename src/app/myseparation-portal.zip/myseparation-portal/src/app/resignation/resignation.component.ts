import { EventEmitterService } from './../services/event-emitter.service';
import { MY_DATE_FORMATS } from './../services/my-date-formats';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { ActiveResignation } from './../interface/activeResignation';
import { Resignation } from './../interface/resignation';
import { DataService } from './../services/data.service';
import { Component, OnInit } from '@angular/core';
import { ResignationService } from '../services/resignation.service';
import { User } from './../interface/user';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar'
import { ResignationwithdrawalComponent } from '../resignationwithdrawal/resignationwithdrawal.component';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ConfirmdialogComponent, ConfirmDialogModel } from '../confirmdialog/confirmdialog.component';
import { WithdrawalService } from '../services/withdrawal.service';
import { ResignationWithdrawal } from '../interface/resignationWithdrawal';
import * as moment from 'moment';
import { FormControl } from '@angular/forms';




@Component({
  selector: 'app-resignation',
  templateUrl: './resignation.component.html',
  styleUrls: ['./resignation.component.css']
})
export class ResignationComponent implements OnInit {

  user: User;
  resignation: Resignation;

  resignationForm: UntypedFormGroup;
  date: Date;
  calculatedDate: Date;
  datePipeString: String;
  activeResignation: Boolean;
  activeResignationData: ActiveResignation;
  submitted: any;
  activeWithdrawal: boolean;
  result: string = '';
  response: String;
  approvalCompleted: boolean;
  activeWithdrawalData: ResignationWithdrawal;
  linemanager: any;
  publicHolidays: any;

  constructor(private fb: UntypedFormBuilder, private dataService: DataService, private withdrawalService: WithdrawalService, private dialog: MatDialog, private resignationService: ResignationService, private datePipe: DatePipe, private snackBar: MatSnackBar, private  eventEmitterService: EventEmitterService) {
    this.resignation = {} as Resignation;
  }

  myFilter = (d: Date | null): boolean => {
    this.publicHolidays = this.dataService.getholidayDates();  //get holidaydates from dataservice that we store from db

   // console.log(this.publicHolidays);
    const day = (d || new Date()).getDay();   // Prevent Saturday and Sunday from being selected.

    const currdate = d.toLocaleDateString();
    const currentdateFormat = this.datePipe.transform(currdate, 'dd-MM-yyyy');   // this will prevent all public holidays from db

    return day !== 0 && day !== 6 &&
    !this.publicHolidays.some( i => i.holidayDate === currentdateFormat);   //will check every day with holiday list and filter if reurn false then disable

  }



  ngOnInit() {
    this.user = this.dataService.getUser();

    this.refresh();
  }

  refresh = () => {

    this.date = new Date();

    this.calculatedDate = new Date();
    this.calculatedDate.setDate(this.date.getDate() + 90);
    //console.log(this.calculatedDate);

   while( this.calculatedDate.getDate() != null) {
    //console.log(this.calculatedDate.getDate());

    if(this.myFilter(this.calculatedDate) == false || this.calculatedDate.getDate() == 1 || this.calculatedDate.getDate() == 2){
          this.calculatedDate =new Date(this.calculatedDate.setDate(this.calculatedDate.getDate() - 1));
         // console.log(this.calculatedDate.getDate());
      }
      else{
            this.datePipeString = this.datePipe.transform(this.calculatedDate, 'dd-MM-yyyy');
        break;
          }
      }

      this.resignationForm = this.fb.group({
      preferredLastWorkingDate: [null, Validators.required],
      systemGeneratedLastWorkingDate: this.datePipeString,
      actualLastWorkingDate: this.datePipeString,
      reason: [null, Validators.required]

    });
    this.resignationService.getActiveResignation(this.user.userId).subscribe(data => {
   
      if (data.id == null) {
        this.activeResignation = false;

      } else {
        this.activeResignationData = data;
        this.activeResignation = true;

        this.approvalCompleted = this.activeResignationData.resignationStatus.hrClearance.clearanceDone;
        this.withdrawalService.getActiveWithdrawal(this.user.userId).subscribe(data => {
          if (data.employeeRemarks == null) {
            this.activeWithdrawal = false;
          } else {
            this.activeWithdrawalData = data;
            this.activeWithdrawal = true;
          }
        });
      }
    });
  }

  resign = () => {
    //For Submitting Resignation Form
    //this.confirmDialog();
    //console.log(this.result)
    this.resignationForm.value.preferredLastWorkingDate = this.datePipe.transform(this.resignationForm.value.preferredLastWorkingDate, 'dd-MM-yyyy');
    this.resignationService.resign(this.resignationForm.value).subscribe(data => {
    this.submitted = data.resignationStatus.overAllStatus == 'SUBMITTED';

      if (this.submitted) {
        this.snackBar.open('Your Resignation Submitted Successfully', 'OK', {
          duration: 2000,
          verticalPosition: "top",
          horizontalPosition: "right"
        })
      }
      this.refresh();
    }, error => {
        this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 5000,
        verticalPosition: "top",
        horizontalPosition: "right"
      });

    });
  }

  confirmDialog(): void {
    //For Getting Confirmation Dialog Box
    const message = `Do you really want to submit?`;
    const dialogData = new ConfirmDialogModel("Confirmation", message);
    const dialogRef = this.dialog.open(ConfirmdialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      this.result = dialogResult;
      if (this.result) {
        this.resign();
      }
    })
  }
}



