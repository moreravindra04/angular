import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FinanceClearanceComponent } from './finance-clearance.component';

describe('FinanceClearanceComponent', () => {
  let component: FinanceClearanceComponent;
  let fixture: ComponentFixture<FinanceClearanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FinanceClearanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FinanceClearanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
