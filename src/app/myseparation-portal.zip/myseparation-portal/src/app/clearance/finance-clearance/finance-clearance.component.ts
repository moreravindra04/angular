import { ResignationService } from './../../services/resignation.service';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { FinanceClearance } from './../../interface/financeClearance';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-finance-clearance',
  templateUrl: './finance-clearance.component.html',
  styleUrls: ['./finance-clearance.component.css']
})
export class FinanceClearanceComponent implements OnInit {

  @Input() 
  selectedUser: string;

  @Input() 
  financeClearance: FinanceClearance;

  @Input()
  actualDate: string;

  @Input() 
  userRole: string;

  @Output() submitted = new EventEmitter();

  approved: boolean; 

  formDisable: boolean;

  status = [
    {key: 'PENDING_FINANCE_CLEARANCE', value: 'Pending'},
    {key: 'APPROVED', value: 'Approved'}
  ]; 
  

  constructor(private fb: UntypedFormBuilder, private resignationService: ResignationService,private snackBar:MatSnackBar) { }

  financeClearanceForm = this.fb.group({
    id: null,
    actualLastWorkingDate: null,
    approvalStatus: [null, Validators.required],
    remarks: [null, Validators.required]      
  }); 

  ngOnInit(): void {
    
    
    
    this.formDisable = this.userRole != 'FINANCE_ADMIN';
    
    this.financeClearanceForm.controls.id.patchValue(this.financeClearance.id);
    this.financeClearanceForm.controls.actualLastWorkingDate.patchValue(this.actualDate);
    this.financeClearanceForm.controls.approvalStatus.patchValue(this.financeClearance.approvalStatus);  
    this.financeClearanceForm.controls.remarks.patchValue(this.financeClearance.remarks); 
    
    this.approved = this.financeClearance.approvalStatus == 'APPROVED'
  }

  submit = () => {   
    this.financeClearanceForm.value.approvalStatus ='APPROVED';
    this.resignationService.financeClearance(this.selectedUser, this.financeClearanceForm.value).subscribe(data => {
      this.approved = data.approvalStatus == 'APPROVED'
      if(this.approved){
        this.snackBar.open('Finance Approval Submitted Successfully', 'OK',{
         duration:2000,
         verticalPosition: "top",
      horizontalPosition:"right"
       })
    }
      this.submitted.emit();
    },error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
        horizontalPosition:"right"
      });
    
    } 
    );    
  }
  
}
