import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PMClearanceComponent } from './pmclearance.component';

describe('PMClearanceComponent', () => {
  let component: PMClearanceComponent;
  let fixture: ComponentFixture<PMClearanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PMClearanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PMClearanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
