import { DatePipe } from '@angular/common';
import { ResignationService } from './../../services/resignation.service';
import { ManagerClearance } from './../../interface/managerClearance';
import { FormGroup, UntypedFormBuilder, Validators } from '@angular/forms';
import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

import * as _moment from 'moment';
import { Moment } from 'moment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { DataService } from 'src/app/services/data.service';

const moment = _moment;

@Component({
  selector: 'app-pmclearance',
  templateUrl: './pmclearance.component.html',
  styleUrls: ['./pmclearance.component.css']
})
export class PMClearanceComponent implements OnInit {

  @Input() 
  selectedUser: String;

  @Input() 
  pmClearance: ManagerClearance;

  @Input() 
  userRole: string;

  @Output() submitted = new EventEmitter();

  date: Date;

  approved: boolean;

  formDisable: boolean;

  status = [
    {key: 'PENDING_MANAGER_CLEARANCE', value: 'Pending'},
    {key: 'APPROVED', value: 'Approved'}
  ];  

  myFilter = (d: Date | null): boolean => {
    this.publicHolidays = this.dataService.getholidayDates();  //get holidaydates from dataservice that we store from db
    
    const day = (d || new Date()).getDay();   // Prevent Saturday and Sunday from being selected.
   
    const currdate = d.toLocaleDateString();
    const currentdateFormat = this.datePipe.transform(currdate, 'dd-MM-yyyy');   // this will prevent all public holidays from db
    
    return day !== 0 && day !== 6 && 
    !this.publicHolidays.some( i => i.holidayDate === currentdateFormat);   //will check every day with holiday list and filter if reurn false then disable
  
  }
  publicHolidays: any;


  constructor(private dataService :DataService,private fb: UntypedFormBuilder, private resignationService: ResignationService, private snackBar:MatSnackBar,private datePipe: DatePipe) { }

  pmClearanceForm = this.fb.group({
    id: null,
    actualLastWorkingDate: [null , Validators.required],
    projectHandOverCompleted: [null, Validators.required],
    projectAssetsSurrendered: [null, Validators.required],
    appraisalCompleted: [null, Validators.required],    
    approvalStatus: [null, Validators.required],
    rehireAnEmployee: [null, Validators.required],
    remarks: [null, Validators.required]      
  }); 

  ngOnInit(): void {

    this.formDisable = this.userRole != 'PM'  ;
    
    this.date = new Date();
       
    var momentVariable = moment(this.pmClearance.actualLastWorkingDate, 'DD-MM-YYYY');    
    var stringvalue = momentVariable.format('YYYY-MM-DD');    
    
    this.pmClearanceForm.controls.id.patchValue(this.pmClearance.id);
    this.pmClearanceForm.controls.actualLastWorkingDate.patchValue(new Date(stringvalue));
    this.pmClearanceForm.controls.projectHandOverCompleted.patchValue(this.pmClearance.projectHandOverCompleted); 
    this.pmClearanceForm.controls.projectAssetsSurrendered.patchValue(this.pmClearance.projectAssetsSurrendered); 
    this.pmClearanceForm.controls.appraisalCompleted.patchValue(this.pmClearance.appraisalCompleted); 
    this.pmClearanceForm.controls.rehireAnEmployee.patchValue(this.pmClearance.rehireAnEmployee);
    this.pmClearanceForm.controls.approvalStatus.patchValue(this.pmClearance.approvalStatus);  
    this.pmClearanceForm.controls.remarks.patchValue(this.pmClearance.remarks);
        
    this.approved = this.pmClearance.approvalStatus == 'APPROVED'
  }

  submit = () => {   
    this.pmClearanceForm.value.approvalStatus = 'APPROVED';
    this.pmClearanceForm.value.actualLastWorkingDate=this.datePipe.transform(this.pmClearanceForm.value.actualLastWorkingDate,'dd-MM-yyyy');
        
    this.resignationService.pmClearance(this.selectedUser, this.pmClearanceForm.value).subscribe(data => {
      
      this.approved = data.approvalStatus =='APPROVED';
     if(this.approved){
       this.snackBar.open('PM Approval Submitted Successfully', 'OK',{
        duration:2000,
        verticalPosition: "top",
      horizontalPosition:"right"
      })
     }
     
     this.submitted.emit();
    },error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
        horizontalPosition:"right"
      });
    
    } );    

  }
  

}
