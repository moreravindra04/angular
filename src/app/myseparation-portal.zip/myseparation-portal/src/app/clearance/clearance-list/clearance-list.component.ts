import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { User } from 'src/app/interface/user';
import { DataService } from 'src/app/services/data.service';


@Component({
  selector: 'app-clearance-list',
  templateUrl: './clearance-list.component.html',
  styleUrls: ['./clearance-list.component.css']
})
export class ClearanceListComponent implements OnInit{ 

 
  
user :User;
userRole: string;
roleCount:number;
showRadioButton: boolean;
  
  value: any;
  roles: any[];
 
  constructor(private dataService:DataService){
    
  }
  
  ngOnInit(){

    this.user = this.dataService.getUser();
    
    this.roleCount = this.user.roles.length;
    const role = this.user.roles;
    this.userRole = role[1].roleCode;

    if(this.roleCount > 2){
      this.showRadioButton = true;
      this.roles =[role[1].roleCode,role[2].roleCode];
    } 
  }
}

 

 

 

