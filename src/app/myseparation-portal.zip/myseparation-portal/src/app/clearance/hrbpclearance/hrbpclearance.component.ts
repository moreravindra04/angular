
import { DatePipe } from '@angular/common';
import { ResignationService } from './../../services/resignation.service';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { HRClearance } from './../../interface/hrClearance';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import * as _moment from 'moment';
import { Moment } from 'moment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HRBPClearance } from 'src/app/interface/hrbpClearance';

const moment = _moment;


@Component({
  selector: 'app-hrbpclearance',
  templateUrl: './hrbpclearance.component.html',
  styleUrls: ['./hrbpclearance.component.css']
})
export class HrbpclearanceComponent implements OnInit {

  

  @Input()
  selectedUser: String;

  @Input()
  hrbpClearance: HRBPClearance;

  @Input()
  actualDate: string;

  @Input()
  userRole: string;

  date: Date;

  @Output() submitted = new EventEmitter();

  approved: boolean;

  formDisable: boolean;

  reasons = {};

  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    // Prevent Saturday and Sunday from being selected.
    return day !== 0 && day !== 6;
  }

  constructor(private fb: UntypedFormBuilder, private resignationService: ResignationService, private snackBar: MatSnackBar, private datePipe: DatePipe) { }

  hrbpClearanceForm = this.fb.group({
    id: null,
    actualLastWorkingDate: null,
    exitInterviewDone: [null, Validators.required],
    exitInterviewDate: [null, Validators.required],
    remarks: [null, Validators.required]
  });

  ngOnInit(): void {

    this.resignationService.getReasons().subscribe(
      data => {
        this.reasons = data
      });

    this.formDisable = this.userRole != 'HRBP';

    this.date = new Date();

    var momentVariable = moment(this.hrbpClearance.exitInterviewDate, 'DD-MM-YYYY');
    var stringvalue = momentVariable.format('YYYY-MM-DD');

    this.hrbpClearanceForm.controls.id.patchValue(this.hrbpClearance.id);
    this.hrbpClearanceForm.controls.actualLastWorkingDate.patchValue(this.actualDate);
    this.hrbpClearanceForm.controls.exitInterviewDone.patchValue(this.hrbpClearance.exitInterviewDone);
    this.hrbpClearanceForm.controls.exitInterviewDate.patchValue(new Date(stringvalue));
    this.hrbpClearanceForm.controls.approvalStatus.patchValue(this.hrbpClearance.approvalStatus);
    this.hrbpClearanceForm.controls.remarks.patchValue(this.hrbpClearance.remarks);
    // this.hrClearanceForm.controls.resignationReason.patchValue(this.hrClearance.resignationReason);

    this.approved = this.hrbpClearance.approvalStatus == 'APPROVED';
  }

  submit = () => {
    this.hrbpClearanceForm.value.approvalStatus = 'APPROVED';
    this.hrbpClearanceForm.value.actualLastWorkingDate = this.datePipe.transform(this.hrbpClearanceForm.value.exitInterviewDate, 'dd-MM-yyyy');
    this.resignationService.hrbpClearance(this.selectedUser, this.hrbpClearanceForm.value).subscribe(data => {
      this.approved = data.approvalStatus == 'APPROVED';
      if (this.approved) {
        this.snackBar.open('HRBP Approval Submitted Successfully', 'OK', {
          duration: 2000,
          verticalPosition: "top",
          horizontalPosition: "right"
        })
      }
      this.submitted.emit();
    }, error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
        horizontalPosition: "right"
      });

    });
  }


}
