import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HrbpclearanceComponent } from './hrbpclearance.component';

describe('HrbpclearanceComponent', () => {
  let component: HrbpclearanceComponent;
  let fixture: ComponentFixture<HrbpclearanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HrbpclearanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HrbpclearanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
