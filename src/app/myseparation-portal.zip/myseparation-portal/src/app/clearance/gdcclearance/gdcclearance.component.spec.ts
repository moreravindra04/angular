import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GdcclearanceComponent } from './gdcclearance.component';

describe('GdcclearanceComponent', () => {
  let component: GdcclearanceComponent;
  let fixture: ComponentFixture<GdcclearanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GdcclearanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GdcclearanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
