import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Gdcclearance } from 'src/app/interface/gdcclearance';
import { ResignationService } from 'src/app/services/resignation.service';

@Component({
  selector: 'app-gdcclearance',
  templateUrl: './gdcclearance.component.html',
  styleUrls: ['./gdcclearance.component.css']
})
export class GdcclearanceComponent implements OnInit {
  @Input()
  selectedUser: string;
  @Input()
  gdcClearance: Gdcclearance
  @Input()
  actualDate: string;
   @Input()
  userRole: string;
  @Output() submitted = new EventEmitter();

  approved: boolean;
  formDisable: boolean;



  constructor(private fb: UntypedFormBuilder, private resignationService: ResignationService, private snackBar: MatSnackBar, private datePipe: DatePipe) { }

  gdcClearanceForm = this.fb.group({
    id: null,
    actualLastWorkingDate: null,
    approvalStatus: [null, Validators.required],
    remarks: [null, Validators.required]
  });

  ngOnInit(): void {


    this.formDisable = this.userRole != 'GDC_HEAD';

    this.gdcClearanceForm.controls.id.patchValue(this.gdcClearance.id);
    this.gdcClearanceForm.controls.actualLastWorkingDate.patchValue(this.actualDate);
    this.gdcClearanceForm.controls.approvalStatus.patchValue(this.gdcClearance.approvalStatus);
    this.gdcClearanceForm.controls.remarks.patchValue(this.gdcClearance.remarks);


  }

  submit = () => {
   
    this.gdcClearanceForm.value.approvalStatus = 'APPROVED';
    this.resignationService.gdcClearance(this.selectedUser, this.gdcClearanceForm.value).subscribe(data => {
     
      this.approved = data.approvalStatus == 'APPROVED';
      if (this.approved) {
        this.snackBar.open('GDC Approval Submitted Successfully', 'OK', {
          duration: 2000,
          verticalPosition: "top",
          horizontalPosition: "right"
        })
      }
      this.submitted.emit();
    }, error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
        horizontalPosition: "right"
      });
    });
  }

}

