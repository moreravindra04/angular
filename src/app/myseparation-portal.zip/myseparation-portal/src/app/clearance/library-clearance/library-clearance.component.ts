/*
import { LibraryClearance } from './../../interface/libraryClearance';
import { FormBuilder, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ResignationService } from './../../services/resignation.service';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-library-clearance',
  templateUrl: './library-clearance.component.html',
  styleUrls: ['./library-clearance.component.css']
})
export class LibraryClearanceComponent implements OnInit {

  @Input() 
  selectedUser: string;

  @Input() 
  libraryClearance: LibraryClearance;

  @Input()
  actualDate: string;

  @Input() 
  userRole: string;

  @Output() submitted = new EventEmitter();

  approved: boolean;

  formDisable: boolean;

  status = [
    {key: 'PENDING_LIBRARY_CLEARANCE', value: 'Pending'},
    {key: 'APPROVED', value: 'Approved'}
  ]; 

  constructor(private fb: FormBuilder, private resignationService: ResignationService,private snackBar:MatSnackBar, private datePipe: DatePipe) { }

  libraryClearanceForm = this.fb.group({
    id: null,
    actualLastWorkingDate: null,
    approvalStatus: [null, Validators.required],
    remarks: [null, Validators.required]      
  }); 

  ngOnInit(): void {
    
      
    this.formDisable = this.userRole != 'LIBRARY_ADMIN';
    
    this.libraryClearanceForm.controls.id.patchValue(this.libraryClearance.id);
    this.libraryClearanceForm.controls.actualLastWorkingDate.patchValue(this.actualDate);
    this.libraryClearanceForm.controls.approvalStatus.patchValue(this.libraryClearance.approvalStatus);  
    this.libraryClearanceForm.controls.remarks.patchValue(this.libraryClearance.remarks);
    
    this.approved = this.libraryClearance.approvalStatus == 'APPROVED';
  }

  submit = () => {   
    this.libraryClearanceForm.value.approvalStatus = 'APPROVED';
    this.resignationService.libraryClearance(this.selectedUser, this.libraryClearanceForm.value).subscribe(data => {
     
      this.approved = data.approvalStatus == 'APPROVED';
      if(this.approved){
        this.snackBar.open('Library Approval Submitted Successfully', 'OK',{
         duration:2000,
         verticalPosition: "top",
      horizontalPosition:"right"
       })
      }
      this.submitted.emit();
    },error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
        horizontalPosition:"right"
      });
    
    } );    
  }
 
}
*/