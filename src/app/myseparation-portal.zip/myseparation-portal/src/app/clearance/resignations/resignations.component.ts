import { SelectionModel } from '@angular/cdk/collections';
import { Component, Input, OnChanges, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActiveResignation } from 'src/app/interface/activeResignation';
import { Clearance } from 'src/app/interface/clearance';
import { User } from 'src/app/interface/user';
import { DataService } from 'src/app/services/data.service';
import { ResignationService } from 'src/app/services/resignation.service';

@Component({
  selector: 'app-resignations',
  templateUrl: './resignations.component.html',
  styleUrls: ['./resignations.component.css']
})
export class ResignationsComponent implements OnChanges, OnInit {

  @Input()
  user: User;
  @Input()
  userRole: String;
  @Input()
  roleCount: number;
  status: String;
  showTabs: boolean
  dataSource: any;
  activeResignationData: ActiveResignation;
  selectedUser: String;
  edit: boolean;
  selectedIndex: number;
  selection = new SelectionModel<Clearance>(false, null);
  currentRole: String;


  constructor(private resignationService: ResignationService, private dataService: DataService) { }

  //To Refresh List Based On Role Selection
  ngOnChanges(): void {
    this.showTabs = false;
    this.refresh();
  }

  //To display table columns
  displayedColumns: string[] = ['userId', 'name', 'lineManager', 'preferredLastWorkingDate', 'systemGeneratedLastWorkingDate', 'resignationStatus'];

  //To call instance of paginator
  @ViewChild(MatPaginator) paginator: MatPaginator;


  ngOnInit() {
    //For highlighting selected row
    this.selection.changed.subscribe((a) => {
      if (a.added[0])   // will be undefined if no selection
      {
        this.show(a.added[0].userId);
      }
    });
    this.refresh();
  }


  refresh = () => {
      switch (this.userRole) {
      case "PM": {
        this.selectedIndex = 0;
        this.status = "PENDING_MANAGER_CLEARANCE";
        break;
      }
      case "GDC_HEAD": {
        this.selectedIndex = 1;
        this.status = "PENDING_GDC_CLEARANCE";
        break;
      }
      case "IT_MANAGER": {
        this.selectedIndex = 2;
        this.status = "PENDING_IT_CLEARANCE";
        break;
      }
      case "HOUSING_ADMIN": {
        this.selectedIndex = 3;
        this.status = "PENDING_HOUSING_AND_ADMIN_CLEARANCE";
        break;
      }
      case "FINANCE_ADMIN": {
        this.selectedIndex = 4;
        this.status = "PENDING_FINANCE_CLEARANCE";
        break;
      }
      case "HRBP": {
        this.selectedIndex = 5;
        this.status = "PENDING_HRBP_CLEARANCE";
        break;
      }
      case "HR": {
        this.selectedIndex = 6;
        this.status = "PENDING_HR_CLEARANCE";
        break;
      }
   
      default: {
        break;
      }
    }

    //search resignation by line manager id and status
    if (this.userRole == 'PM') {
      this.resignationService.getResignationsByManagerAndStatus(this.status, this.user.userId).subscribe(data => {
        this.dataSource = new MatTableDataSource<Clearance>(data);
        this.dataSource.paginator = this.paginator;

      });
    }
    else {
      //search resignation By status
      this.resignationService.getResignationsByStatus(this.status).subscribe(data => {
        this.dataSource = new MatTableDataSource<Clearance>(data);
        this.dataSource.paginator = this.paginator;
      });
    }
  }


  //To show clearance Tabs based On selection of particular resignations
  show = (selectedUser: String) => {
    this.showTabs = false;
    this.selectedUser = selectedUser;
    this.resignationService.getActiveResignation(this.selectedUser).subscribe(data => {
      this.edit = data.resignationStatus.overAllStatus == 'WITHDRAWAL_SUBMITTED';
      if (this.edit) {
        this.showTabs = false;
      }
      else {
        this.showTabs = true;
      }
      this.activeResignationData = data;
    });
  }
}