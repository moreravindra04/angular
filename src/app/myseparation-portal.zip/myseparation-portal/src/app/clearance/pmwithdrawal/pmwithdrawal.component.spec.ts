import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PmwithdrawalComponent } from './pmwithdrawal.component';

describe('PmwithdrawalComponent', () => {
  let component: PmwithdrawalComponent;
  let fixture: ComponentFixture<PmwithdrawalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PmwithdrawalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PmwithdrawalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
