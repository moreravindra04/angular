import { DatePipe } from '@angular/common';
import { Component, Input, OnInit, Output } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { EventEmitter } from '@angular/core';
import * as moment from 'moment';
import { ResignationWithdrawal } from 'src/app/interface/resignationWithdrawal';
import { ResignationwithdrawalComponent } from 'src/app/resignationwithdrawal/resignationwithdrawal.component';
import { ResignationService } from 'src/app/services/resignation.service';
import { WithdrawalService } from 'src/app/services/withdrawal.service';
import { DataService } from 'src/app/services/data.service';


@Component({
  selector: 'app-pmwithdrawal',
  templateUrl: './pmwithdrawal.component.html',
  styleUrls: ['./pmwithdrawal.component.css']
})
export class PmwithdrawalComponent implements OnInit {
 
  dates: any;


  @Input() 
  pmWithdrawal:ResignationWithdrawal;
  @Input()
  selectedUser: String;
  date: Date;
  approved: boolean;
  formDisable: boolean;

  @Input() 
  userRole: string;

  @Output() submitted = new EventEmitter();
  
  myFilter = (d: Date | null): boolean => {
    
    const day = (d || new Date()).getDay();   
   
    return day !== 0 && day !== 6 ;  
    
  }

 

  constructor(private fb: UntypedFormBuilder,  private dataService: DataService,private snackBar:MatSnackBar,private withdrawalService: WithdrawalService, private datePipe: DatePipe) { }

  pmWithdrawalForm = this.fb.group({
  
    resignationWithdrawalDate: [null , Validators.required],
    employeeRemarks:[null,Validators.required],
    managerRemarks: [null, Validators.required],
    approvalStatus: ['APPROVED', Validators.required]       
  }); 


  ngOnInit(): void {
   
    this.formDisable = this.userRole != 'PM';
    this.date = new Date();
    var momentVariable = moment(this.pmWithdrawal.createdDate, 'DD-MM-YYYY');    
    var stringvalue = momentVariable.format('YYYY-MM-DD');
      
    this.pmWithdrawalForm.controls.resignationWithdrawalDate.patchValue(new Date(stringvalue));
    this.pmWithdrawalForm.controls.employeeRemarks.patchValue(this.pmWithdrawal.employeeRemarks); 
    this.pmWithdrawalForm.controls.managerRemarks.patchValue(this.pmWithdrawal.managerRemarks); 
    
    
     this.approved=this.pmWithdrawal.approvalStatus == "PENDING_GDC_HEAD_WITHDRAWAL_CLEARANCE";
  }
  

  submit = () =>{

  
  this.pmWithdrawalForm.value.resignationWithdrawalDate=this.datePipe.transform(this.pmWithdrawalForm.value.resignationWithdrawalDate,'dd-MM-yyyy');
    this.withdrawalService.pmWithdrawal(this.selectedUser, this.pmWithdrawalForm.value).subscribe(data => {
     this.approved = data.approvalStatus == 'PENDING_GDC_HEAD_WITHDRAWAL_CLEARANCE'
    if(this.approved){
      this.snackBar.open('PM Approval For Withdrawal Submitted Successfully', 'OK',{
       duration:2000,
       verticalPosition: "top",
      horizontalPosition:"right"
     })
    }
    this.submitted.emit();
  },error => {
    this.snackBar.open("Something Went Wrong", "RETRY", {
      duration: 3000,
      verticalPosition: "top",
      horizontalPosition:"right"
    });
  
  } );  
}
onClick=()=> {
  this.pmWithdrawalForm.value.approvalStatus='REJECTED';
  this.pmWithdrawalForm.value.resignationWithdrawalDate=this.datePipe.transform(this.pmWithdrawalForm.value.resignationWithdrawalDate,'dd-MM-yyyy');
  this.withdrawalService.pmWithdrawal(this.selectedUser, this.pmWithdrawalForm.value).subscribe(data => {
  this.approved = data.approvalStatus == 'REJECTED'
  if(this.approved){
    this.snackBar.open('PM Rejection For Withdrawal Submitted Successfully', 'OK',{
     duration:2000,
     verticalPosition: "top",
      horizontalPosition:"right"
   })
  }
  this.submitted.emit();
},error => {
  this.snackBar.open("Something Went Wrong", "RETRY", {
    duration: 3000,
    verticalPosition: "top",
    horizontalPosition:"right"
  });

} );  

}

}



