import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GdcwithdrawalComponent } from './gdcwithdrawal.component';

describe('GdcwithdrawalComponent', () => {
  let component: GdcwithdrawalComponent;
  let fixture: ComponentFixture<GdcwithdrawalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GdcwithdrawalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GdcwithdrawalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
