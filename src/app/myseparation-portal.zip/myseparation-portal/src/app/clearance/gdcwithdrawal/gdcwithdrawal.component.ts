import { DatePipe } from '@angular/common';
import { Input } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Validators } from '@angular/forms';
import { UntypedFormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { ResignationWithdrawal } from 'src/app/interface/resignationWithdrawal';
import { WithdrawalService } from 'src/app/services/withdrawal.service';

@Component({
  selector: 'app-gdcwithdrawal',
  templateUrl: './gdcwithdrawal.component.html',
  styleUrls: ['./gdcwithdrawal.component.css']
})
export class GdcwithdrawalComponent implements OnInit {

  date: Date;

  approved: boolean;


  @Input()
  selectedUser: String;

  @Input()
  userRole: string;

  @Input()
  gdcWithdrawal: ResignationWithdrawal;

  formDisable: boolean;

  @Output() submitted = new EventEmitter();

  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    // Prevent Saturday and Sunday from being selected.
    return day !== 0 && day !== 6;
  }
  constructor(private fb: UntypedFormBuilder, private snackBar: MatSnackBar, private withdrawalService: WithdrawalService, private datePipe: DatePipe) { }

  gdcWithdrawalForm = this.fb.group({
    resignationWithdrawalDate: [null, Validators.required],
    employeeRemarks: [null, Validators.required],
    managerRemarks: [null, Validators.required],
    gdcheadRemarks:[null, Validators.required],
    approvalStatus: ['APPROVED', Validators.required]
  });


  ngOnInit(): void {
    this.formDisable = this.userRole != 'GDC_HEAD';
  
    this.date = new Date();
    var momentVariable = moment(this.gdcWithdrawal.createdDate, 'DD-MM-YYYY');
    var stringvalue = momentVariable.format('YYYY-MM-DD');


    this.gdcWithdrawalForm.controls.resignationWithdrawalDate.patchValue(new Date(stringvalue));
    this.gdcWithdrawalForm.controls.employeeRemarks.patchValue(this.gdcWithdrawal.employeeRemarks);
    this.gdcWithdrawalForm.controls.managerRemarks.patchValue(this.gdcWithdrawal.managerRemarks);
    this.gdcWithdrawalForm.controls.gdcheadRemarks.patchValue(this.gdcWithdrawal.gdcheadRemarks);
    this.approved = this.gdcWithdrawal.approvalStatus == 'APPROVED'

  }


  submit = () => {

    this.gdcWithdrawalForm.value.resignationWithdrawalDate = this.datePipe.transform(this.gdcWithdrawalForm.value.resignationWithdrawlDate, 'dd-MM-yyyy');
    this.withdrawalService.gdcheadWithdrawal(this.selectedUser, this.gdcWithdrawalForm.value).subscribe(data => {
       this.approved = data.approvalStatus == 'COMPLETED'
      if (this.approved) {
        this.snackBar.open('GDC Approval For Withdrawal Submitted Successfully', 'OK', {
          duration: 2000,
          verticalPosition: "top",
          horizontalPosition: "right"
        })

      }
      this.submitted.emit();
    }, error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
        horizontalPosition: "right"
      });

    });
  }

  onClick = () => {

    this.gdcWithdrawalForm.value.approvalStatus = 'REJECTED';
    this.gdcWithdrawalForm.value.resignationWithdrawalDate = this.datePipe.transform(this.gdcWithdrawalForm.value.resignationWithdrawlDate, 'dd-MM-yyyy');
    this.withdrawalService.gdcheadWithdrawal(this.selectedUser, this.gdcWithdrawalForm.value).subscribe(data => {
      this.approved = data.approvalStatus == 'REJECTED'
      if (this.approved) {
        this.snackBar.open('GDC Rejection For Withdrawal Submitted Successfully', 'OK', {
          duration: 2000,
          verticalPosition: "top",
          horizontalPosition: "right"
        })
      }
      this.submitted.emit();
    }, error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
        horizontalPosition: "right"
      });

    });

  }}
