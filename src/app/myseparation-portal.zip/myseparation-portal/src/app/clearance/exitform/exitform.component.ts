import { Component, Input, OnInit, Output } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, FormGroupName, Validators } from '@angular/forms';
import { ActiveResignation } from 'src/app/interface/activeResignation';
import { User } from 'src/app/interface/user';
import { DataService } from 'src/app/services/data.service';
import { ResignationService } from 'src/app/services/resignation.service';
import { UserAuthService } from 'src/app/services/user-auth.service';
import jspdf from 'jspdf'
import html2canvas from 'html2canvas'
import { Resignation } from 'src/app/interface/resignation';
import { EventEmitter } from 'events';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-exitform',
  templateUrl: './exitform.component.html',
  styleUrls: ['./exitform.component.css']
})
export class ExitformComponent implements OnInit {

  user: User;
  approvalCompleted: boolean;
  activeResignationData: ActiveResignation;
  exitForm: UntypedFormGroup;
  exitFromValue: string;
  currentResination: ActiveResignation;
  awlform: FormGroupName;
  otherform: FormGroupName;
  reasonform: FormGroupName;


  constructor(private fb: UntypedFormBuilder, private dataService: DataService, private resignationService: ResignationService,private snackBar:MatSnackBar) { }
  ngOnInit(): void {

    this.user = this.dataService.getUser();
    this.refresh();

    this.resignationService.getActiveResignation(this.user.userId).subscribe(data => {
      
      this.currentResination = data;
      
      const jsonData = JSON.parse(this.currentResination.jsonData);
      this.exitForm.get('reasonform.reason').patchValue(jsonData.reasonform.reason);
      this.exitForm.get('reasonform.reason_betterSalary').patchValue(jsonData.reasonform.reason_betterSalary);
      this.exitForm.get('reasonform.reason_carrierExpectation').patchValue(jsonData.reasonform.reason_carrierExpectation);
      this.exitForm.get('reasonform.reason_workHours').patchValue(jsonData.reasonform.reason_workHours);
      this.exitForm.get('reasonform.reason_workLocation').patchValue(jsonData.reasonform.reason_workLocation);
      this.exitForm.get('reasonform.reason_furtherEducation').patchValue(jsonData.reasonform.reason_furtherEducation);
      this.exitForm.get('reasonform.reason_performance').patchValue(jsonData.reasonform.reason_performance);
      this.exitForm.get('reasonform.reason_undesirableConduct').patchValue(jsonData.reasonform.reason_undesirableConduct);
      this.exitForm.get('reasonform.reason_normalRetirement').patchValue(jsonData.reasonform.reason_normalRetirement);
      this.exitForm.get('reasonform.reason_death').patchValue(jsonData.reasonform.reason_death);
      this.exitForm.get('reasonform.reason_redundancyAndDispute').patchValue(jsonData.reasonform.reason_redundancyAndDispute);
      this.exitForm.get('reasonform.reason_changeCompanies').patchValue(jsonData.reasonform.reason_changeCompanies);
      this.exitForm.get('reasonform.reason_endOfTempContract').patchValue(jsonData.reasonform.reason_endOfTempContract);
      this.exitForm.get('reasonform.reason_noShow').patchValue(jsonData.reasonform.reason_noShow);
      this.exitForm.get('reasonform.reason_medicalDisabled').patchValue(jsonData.reasonform.reason_medicalDisabled);
      this.exitForm.get('reasonform.reason_forcedRedundancy').patchValue(jsonData.reasonform.reason_forcedRedundancy);
      this.exitForm.get('reasonform.reasons_2').patchValue(jsonData.reasonform.reasons_2);
      this.exitForm.get('reasonform.reasons_2a').patchValue(jsonData.reasonform.reasons_2a);
      this.exitForm.get('reasonform.reasons_2b').patchValue(jsonData.reasonform.reasons_2b);
      this.exitForm.get('reasonform.reasons_2c').patchValue(jsonData.reasonform.reasons_2c);
      this.exitForm.get('reasonform.reasons_2d').patchValue(jsonData.reasonform.reasons_2d);
      this.exitForm.get('reasonform.reasons_3').patchValue(jsonData.reasonform.reasons_3);
      this.exitForm.get('reasonform.reasons_3a').patchValue(jsonData.reasonform.reasons_3a);
      this.exitForm.get('reasonform.reasons_3b').patchValue(jsonData.reasonform.reasons_3b);
      this.exitForm.get('reasonform.reasons_4').patchValue(jsonData.reasonform.reasons_4);
      this.exitForm.get('reasonform.reasons_5').patchValue(jsonData.reasonform.reasons_5);
      this.exitForm.get('reasonform.reasons_6').patchValue(jsonData.reasonform.reasons_6);

      this.exitForm.get('awlform.awl_1').patchValue(jsonData.awlform.awl_1);
      this.exitForm.get('awlform.awl_1a').patchValue(jsonData.awlform.awl_1a);
      this.exitForm.get('awlform.awl_1b').patchValue(jsonData.awlform.awl_1b);
      this.exitForm.get('awlform.awl_2').patchValue(jsonData.awlform.awl_2);
      this.exitForm.get('awlform.awl_2a').patchValue(jsonData.awlform.awl_2a);
      this.exitForm.get('awlform.awl_2b').patchValue(jsonData.awlform.awl_2b);
      this.exitForm.get('awlform.awl_holiday').patchValue(jsonData.awlform.awl_holiday);
      this.exitForm.get('awlform.awl_insurance').patchValue(jsonData.awlform.awl_insurance);
      this.exitForm.get('awlform.awl_benefits').patchValue(jsonData.awlform.awl_benefits);
      this.exitForm.get('awlform.awl_3').patchValue(jsonData.awlform.awl_3);
      this.exitForm.get('awlform.awl_3a').patchValue(jsonData.awlform.awl_3a);
      this.exitForm.get('awlform.awl_4').patchValue(jsonData.awlform.awl_4);
      this.exitForm.get('awlform.awl_5').patchValue(jsonData.awlform.awl_5);
      this.exitForm.get('awlform.awl_5a').patchValue(jsonData.awlform.awl_5a);
      this.exitForm.get('awlform.awl_5b').patchValue(jsonData.awlform.awl_5b);

      this.exitForm.get('otherform.other_1').patchValue(jsonData.otherform.other_1);
      this.exitForm.get('otherform.other_2').patchValue(jsonData.otherform.other_2);
      this.exitForm.get('otherform.other_3').patchValue(jsonData.otherform.other_3);
      this.exitForm.get('otherform.other_4').patchValue(jsonData.otherform.other_4);
      this.exitForm.get('otherform.other_5').patchValue(jsonData.otherform.other_5);
      this.exitForm.get('otherform.other_6').patchValue(jsonData.otherform.other_6);
      this.exitForm.get('otherform.other_7').patchValue(jsonData.otherform.other_7);
      this.exitForm.get('otherform.other_7a').patchValue(jsonData.otherform.other_7a);
      this.exitForm.get('otherform.other_8').patchValue(jsonData.otherform.other_8);
      this.exitForm.get('otherform.other_9').patchValue(jsonData.otherform.other_9);
    });

  }


  refresh = () => {
    this.exitForm = this.fb.group({

      reasonform: this.fb.group({
        reason: [null, Validators.required],
        reason_betterSalary: [null, Validators.required],
        reason_carrierExpectation: [null, Validators.required],
        reason_workHours: [null, Validators.required],
        reason_workLocation: [null, Validators.required],
        reason_furtherEducation: [null, Validators.required],
        reason_performance: [null, Validators.required],
        reason_undesirableConduct: [null, Validators.required],
        reason_normalRetirement: [null, Validators.required],
        reason_death: [null, Validators.required],
        reason_redundancyAndDispute: [null, Validators.required],
        reason_changeCompanies: [null, Validators.required],
        reason_endOfTempContract: [null, Validators.required],
        reason_noShow: [null, Validators.required],
        reason_medicalDisabled: [null, Validators.required],
        reason_forcedRedundancy: [null, Validators.required],
        reasons_2: [null, Validators.required],
        reasons_2a: [null, Validators.required],
        reasons_2b: [null, Validators.required],
        reasons_2c: [null, Validators.required],
        reasons_2d: [null, Validators.required],
        reasons_3: [null, Validators.required],
        reasons_3a: [null, Validators.required],
        reasons_3b: [null, Validators.required],
        reasons_4: [null, Validators.required],
        reasons_5: [null, Validators.required],
        reasons_6: [null, Validators.required]
      }),

      awlform: this.fb.group({

        awl_1: [null, Validators.required],
        awl_1a: [null, Validators.required],
        awl_1b: [null, Validators.required],
        awl_2: [null, Validators.required],
        awl_2a: [null, Validators.required],
        awl_2b: [null, Validators.required],
        awl_holiday: [null, Validators.required],
        awl_insurance: [null, Validators.required],
        awl_benefits: [null, Validators.required],
        awl_3: [null, Validators.required],
        awl_3a: [null, Validators.required],
        awl_4: [null, Validators.required],
        awl_5: [null, Validators.required],
        awl_5a: [null, Validators.required],
        awl_5b: [null, Validators.required]

      }),

      otherform: this.fb.group({

        other_1: [null, Validators.required],
        other_2: [null, Validators.required],
        other_3: [null, Validators.required],
        other_4: [null, Validators.required],
        other_5: [null, Validators.required],
        other_6: [null, Validators.required],
        other_7: [null, Validators.required],
        other_7a: [null, Validators.required],
        other_8: [null, Validators.required],
        other_9: [null, Validators.required]
      })

    });
  }

  generatePdf(data) {
    html2canvas(data, { allowTaint: true }).then(canvas => {
       const HTML_Width = canvas.width;
       const HTML_Height = canvas.height;
      const top_left_margin = 5;
      const PDF_Width = HTML_Width + (top_left_margin * 2);
      const PDF_Height = (PDF_Width * 1.5) + (top_left_margin * 2);
      const canvas_image_width = HTML_Width;
      const canvas_image_height = HTML_Height;
      const totalPDFPages = Math.ceil(HTML_Height / PDF_Height) - 1;
      canvas.getContext('2d');
      const imgData = canvas.toDataURL("image/jpeg", 1.0);
      const pdf = new jspdf('p', 'pt', [PDF_Width, PDF_Height]);
      pdf.addImage(imgData, 'JPG', top_left_margin, top_left_margin, canvas_image_width, canvas_image_height);
      for (let i = 1; i <= totalPDFPages; i++) {
        pdf.addPage([PDF_Width, PDF_Height], 'p');
        pdf.addImage(imgData, 'JPG', top_left_margin, -(PDF_Height * i) + (top_left_margin * 4), canvas_image_width, canvas_image_height);
      }
      pdf.save("EXIT-FORM-Document.pdf");
    });
  }

  submit = () => {
  
    this.exitFromValue = (JSON.stringify(this.exitForm.value));
     this.resignationService.exitForm(this.exitFromValue).subscribe(data => {
      
      
      if(data){
        this.snackBar.open('Exit Form Submitted Successfully', 'OK',{
         duration:2000,
         verticalPosition: "top",
      horizontalPosition:"right"
       })
    }


    },error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
        horizontalPosition:"right"
      });
    
    } 
    ); 
   

  }
}
