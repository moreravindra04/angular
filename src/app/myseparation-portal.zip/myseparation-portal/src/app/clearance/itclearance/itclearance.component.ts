import { ITClearance } from './../../interface/itClearance';
import { DatePipe } from '@angular/common';
import { ResignationService } from './../../services/resignation.service';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-itclearance',
  templateUrl: './itclearance.component.html',
  styleUrls: ['./itclearance.component.css']
})
export class ITClearanceComponent implements OnInit {

  @Input()
  selectedUser: string;

  @Input()
  itClearance: ITClearance;

  @Input()
  actualDate: string;

  @Input()
  userRole: string;

  @Output() submitted = new EventEmitter();

  approved: boolean;

  formDisable: boolean;

  status = [
    { key: 'PENDING_IT_CLEARANCE', value: 'Pending' },
    { key: 'APPROVED', value: 'Approved' }
  ];
  

  constructor(private fb: UntypedFormBuilder, private resignationService: ResignationService, private snackBar: MatSnackBar, private datePipe: DatePipe) { }

  itClearanceForm = this.fb.group({
    id: null,
    actualLastWorkingDate: null,
    laptopSurrendered: [null, Validators.required],
    headphoneSurrendered: [null, Validators.required],
    smartCardSurrendered: [null, Validators.required],
    approvalStatus: [null, Validators.required],
    remarks: [null, Validators.required]
  });

  ngOnInit(): void {

    this.formDisable = this.userRole != 'IT_MANAGER';

    this.itClearanceForm.controls.id.patchValue(this.itClearance.id);
    this.itClearanceForm.controls.actualLastWorkingDate.patchValue(this.actualDate);
    this.itClearanceForm.controls.laptopSurrendered.patchValue(this.itClearance.laptopSurrendered);
    this.itClearanceForm.controls.headphoneSurrendered.patchValue(this.itClearance.headphoneSurrendered);
    this.itClearanceForm.controls.smartCardSurrendered.patchValue(this.itClearance.smartCardSurrendered);
    this.itClearanceForm.controls.approvalStatus.patchValue(this.itClearance.approvalStatus);
    this.itClearanceForm.controls.remarks.patchValue(this.itClearance.remarks);

    this.approved = this.itClearance.approvalStatus == 'APPROVED';
  }

  submit = () => {
    this.itClearanceForm.value.approvalStatus = 'APPROVED';
    this.resignationService.itClearance(this.selectedUser, this.itClearanceForm.value).subscribe(data => {
      this.approved = data.approvalStatus == 'APPROVED';
      if (this.approved) {
        this.snackBar.open('IT Approval Submitted Successfully', 'OK', {
          duration: 2000,
          verticalPosition: "top",
      horizontalPosition:"right"
        })
      }
      
      this.submitted.emit();
    },error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
        horizontalPosition:"right"
      });
    
    } );
  }


}
