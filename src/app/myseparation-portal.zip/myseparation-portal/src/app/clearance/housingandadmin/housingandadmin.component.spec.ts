import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HousingandadminComponent } from './housingandadmin.component';

describe('HousingandadminComponent', () => {
  let component: HousingandadminComponent;
  let fixture: ComponentFixture<HousingandadminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HousingandadminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HousingandadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
