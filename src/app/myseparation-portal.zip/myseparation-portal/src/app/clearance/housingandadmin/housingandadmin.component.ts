import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HousingandadminClearance } from 'src/app/interface/housingandadminClearance';
import { ResignationService } from 'src/app/services/resignation.service';

@Component({
  selector: 'app-housingandadmin',
  templateUrl: './housingandadmin.component.html',
  styleUrls: ['./housingandadmin.component.css']
})
export class HousingandadminComponent implements OnInit {


  @Input() 
  selectedUser: string;

  @Input()
  housingAndAdminClearance: HousingandadminClearance;

  
  @Input()
  actualDate: string;

  @Input() 
  userRole: string;

  @Output() submitted = new EventEmitter();

  approved: boolean;

  formDisable: boolean;

  status = [
    {key: 'PENDING_HOUSING_AND_ADMIN_CLEARANCE', value: 'Pending'},
    {key: 'APPROVED', value: 'Approved'}
  ]; 

  constructor(private fb: UntypedFormBuilder, private resignationService: ResignationService,private snackBar:MatSnackBar, private datePipe: DatePipe) { }

  housingAndAdminClearanceForm = this.fb.group({
    id: null,
    actualLastWorkingDate: null,
    libraryBooksSurrendered: [null, Validators.required],
    powerOfAttorney: [null, Validators.required],
    canteenCleared: [null, Validators.required],
    identityAndAccessCardSurrendered: [null, Validators.required],
    parkingPassSurrendered: [null, Validators.required],
    drawerKeysSurrendered: [null, Validators.required],
    approvalStatus: [null, Validators.required],
    remarks: [null, Validators.required]      
  }); 


  ngOnInit(): void {

 
    this.formDisable = this.userRole != 'HOUSING_ADMIN';

    this.housingAndAdminClearanceForm.controls.id.patchValue(this.housingAndAdminClearance.id);
    this.housingAndAdminClearanceForm.controls.actualLastWorkingDate.patchValue(this.actualDate);

    this.housingAndAdminClearanceForm.controls.libraryBooksSurrendered.patchValue(this.housingAndAdminClearance.libraryBooksSurrendered);
    this.housingAndAdminClearanceForm.controls.powerOfAttorney.patchValue(this.housingAndAdminClearance.powerOfAttorney);
    this.housingAndAdminClearanceForm.controls.canteenCleared.patchValue(this.housingAndAdminClearance.canteenCleared);
    this.housingAndAdminClearanceForm.controls.identityAndAccessCardSurrendered.patchValue(this.housingAndAdminClearance.identityAndAccessCardSurrendered);
    this.housingAndAdminClearanceForm.controls.parkingPassSurrendered.patchValue(this.housingAndAdminClearance.parkingPassSurrendered);
    this.housingAndAdminClearanceForm.controls.drawerKeysSurrendered.patchValue(this.housingAndAdminClearance.drawerKeysSurrendered);


    this.housingAndAdminClearanceForm.controls.approvalStatus.patchValue(this.housingAndAdminClearance.approvalStatus);
    this.housingAndAdminClearanceForm.controls.remarks.patchValue(this.housingAndAdminClearance.remarks);

    this.approved = this.housingAndAdminClearance.approvalStatus  == 'APPROVED';
  }

  submit = () => {   
    this.housingAndAdminClearanceForm.value.approvalStatus = 'APPROVED';
    this.resignationService.housingAndAdminClearance(this.selectedUser, this.housingAndAdminClearanceForm.value).subscribe(data=>{
    
      this.approved = data.approvalStatus == 'APPROVED';
      if (this.approved) {
        this.snackBar.open('Housing and Admin Approval Submitted Successfully', 'OK', {
          duration: 2000,
          verticalPosition: "top",
      horizontalPosition:"right"
      })
    }
    this.submitted.emit();
    },error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
        horizontalPosition:"right"
      });
    
    } );
  }  
}
