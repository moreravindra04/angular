import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HRClearanceComponent } from './hrclearance.component';

describe('HRClearanceComponent', () => {
  let component: HRClearanceComponent;
  let fixture: ComponentFixture<HRClearanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HRClearanceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HRClearanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
