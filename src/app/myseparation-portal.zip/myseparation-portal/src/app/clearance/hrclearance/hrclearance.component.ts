import { DatePipe } from '@angular/common';
import { ResignationService } from './../../services/resignation.service';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { HRClearance } from './../../interface/hrClearance';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import * as _moment from 'moment';
import { Moment } from 'moment';
import { MatSnackBar } from '@angular/material/snack-bar';

const moment = _moment;

@Component({
  selector: 'app-hrclearance',
  templateUrl: './hrclearance.component.html',
  styleUrls: ['./hrclearance.component.css']
})
export class HRClearanceComponent implements OnInit {

  @Input()
  selectedUser: String;

  @Input()
  hrClearance: HRClearance;

  @Input()
  actualDate: string;

  @Input()
  userRole: string;

  date: Date;

  @Output() submitted = new EventEmitter();

  approved: boolean;

  formDisable: boolean;

  reasons = {};

  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    // Prevent Saturday and Sunday from being selected.
    return day !== 0 && day !== 6;
  }

  constructor(private fb: UntypedFormBuilder, private resignationService: ResignationService, private snackBar: MatSnackBar, private datePipe: DatePipe) { }

  hrClearanceForm = this.fb.group({
    id: null,
    actualLastWorkingDate: null,
      remarks: [null, Validators.required]
  });

  ngOnInit(): void {

    this.formDisable = this.userRole != 'HR';

    this.date = new Date();
    this.hrClearanceForm.controls.id.patchValue(this.hrClearance.id);
    this.hrClearanceForm.controls.actualLastWorkingDate.patchValue(this.actualDate);
   this.hrClearanceForm.controls.remarks.patchValue(this.hrClearance.remarks);
   

    this.approved = this.hrClearance.approvalStatus == 'APPROVED';
  }

  submit = () => {
    this.hrClearanceForm.value.approvalStatus = 'APPROVED';
    this.hrClearanceForm.value.actualLastWorkingDate = this.datePipe.transform(this.hrClearanceForm.value.exitInterviewDate, 'dd-MM-yyyy');
    this.resignationService.hrClearance(this.selectedUser, this.hrClearanceForm.value).subscribe(data => {
      this.approved = data.approvalStatus == 'APPROVED';
      if (this.approved) {
        this.snackBar.open('HR Approval Submitted Successfully', 'OK', {
          duration: 2000,
          verticalPosition: "top",
          horizontalPosition: "right"
        })
      }
      this.submitted.emit();
    }, error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
        horizontalPosition: "right"
      });

    });
  }


}
