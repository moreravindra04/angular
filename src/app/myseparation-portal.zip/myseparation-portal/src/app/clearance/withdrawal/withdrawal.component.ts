import { SelectionModel } from '@angular/cdk/collections';
import { Input } from '@angular/core';
import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ActiveResignation } from 'src/app/interface/activeResignation';
import { ActiveWithdrawal } from 'src/app/interface/activeWithdrawal';
import { Clearance } from 'src/app/interface/clearance';
import { ResignationWithdrawal } from 'src/app/interface/resignationWithdrawal';
import { User } from 'src/app/interface/user';
import { DataService } from 'src/app/services/data.service';
import { ResignationService } from 'src/app/services/resignation.service';
import { WithdrawalService } from 'src/app/services/withdrawal.service';

@Component({
  selector: 'app-withdrawal',
  templateUrl: './withdrawal.component.html',
  styleUrls: ['./withdrawal.component.css']
})
export class WithdrawalComponent implements OnInit {
 
  status: String;
  showTabs: boolean
  dataSource: any;
  
  activeResignationData : ActiveResignation;
  selectedUser: String;
  activeWithdrawalData: ResignationWithdrawal;
  selection = new SelectionModel<ActiveWithdrawal>(false, null);
  
  selectedIndex: number;
  @Input() 
  userRole: string;
  //@Output() valueinparentchange = new EventEmitter<boolean>();
  
   
  @Input() 
  user: User;


  constructor( private dataService: DataService,private withdrawalService:WithdrawalService) { }
  //displayedColumns: string[] = ['userId', 'name', 'email', 'lineManager', 'actualLastWorkingDate', 'resignationStatus', 'actions'];
  displayedColumns: string[] = ['userId', 'name', 'email', 'lineManager', 'actualLastWorkingDate', 'resignationStatus'];
  

  @ViewChild(MatPaginator,{static:true}) paginator: MatPaginator;


  ngOnChanges():void{
    this.showTabs=false;
    this.refresh();
  } 

  ngOnInit(){
    
    // selection changed
    this.selection.changed.subscribe((a) =>
    {
        if (a.added[0])   // will be undefined if no selection
        {
            this.show(a.added[0].userId);
        }
    });

    //this.user = this.dataService.getUser();
    //const role = this.user.roles;
    //this.userRole = role[1].roleCode;
    this.refresh();
  }

  refresh = () =>{
   
    switch(this.userRole) { 
      case "PM": { 
        this.status = "PENDING_PM_WITHDRAWAL_CLEARANCE";
        this.selectedIndex = 0;
        break; 
      } 
      
      case "GDC_HEAD": { 
        this.status = "PENDING_GDC_WITHDRAWAL_CLEARANCE";
        break; 
      }  
      case "HRBP": { 
        this.status = "PENDING_HRBP_WITHDRAWAL_CLEARANCE";
        this.selectedIndex = 2;
        break; 
      }  
      default: { 
        console.log("Invalid Role"); 
        break;              
      }      
   }

    if (this.userRole == 'PM') {
      this.withdrawalService.getWithdrawalsByManagerAndStatus(this.status, this.user.userId).subscribe(data => {
        this.dataSource = new MatTableDataSource<ActiveWithdrawal>(data);
        this.dataSource.paginator = this.paginator;

      });
    } else {
      this.withdrawalService.getWithdrawalsByStatus(this.status).subscribe(data => {
        this.dataSource = new MatTableDataSource<ActiveWithdrawal>(data);
        this.dataSource.paginator = this.paginator;        
      });
    }
  }

  

  show = (selectedUser: String) => {   
    this.showTabs = false;
    this.selectedUser = selectedUser;
  

    this.withdrawalService.getActiveWithdrawal(this.selectedUser).subscribe(data => {   
      this.showTabs = true;
     this.activeWithdrawalData = data;
    });       
  }

 
}
