import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import * as moment from 'moment';
import { HRClearance } from 'src/app/interface/hrClearance';
import { ResignationWithdrawal } from 'src/app/interface/resignationWithdrawal';
import { ResignationService } from 'src/app/services/resignation.service';
import { WithdrawalService } from 'src/app/services/withdrawal.service';



@Component({
  selector: 'app-hrbpwithdrawal',
  templateUrl: './hrbpwithdrawal.component.html',
  styleUrls: ['./hrbpwithdrawal.component.css']
})
export class HrbpwithdrawalComponent implements OnInit {
 date: Date;
  
    approved: boolean;
  
  
    @Input()
    selectedUser: String;
  
    @Input()
    userRole: string;
  
    @Input()
    hrbpWithdrawal: ResignationWithdrawal;
  
    formDisable: boolean;
  
    @Output() submitted = new EventEmitter();
  
    myFilter = (d: Date | null): boolean => {
      const day = (d || new Date()).getDay();
      // Prevent Saturday and Sunday from being selected.
      return day !== 0 && day !== 6;
    }
    constructor(private fb: UntypedFormBuilder, private snackBar: MatSnackBar, private withdrawalService: WithdrawalService, private datePipe: DatePipe) { }
  
    hrbpWithdrawalForm = this.fb.group({
      resignationWithdrawalDate: [null, Validators.required],
      employeeRemarks: [null, Validators.required],
      managerRemarks: [null, Validators.required],
      gdcheadRemarks:[null, Validators.required],
      hrbpRemarks: [null, Validators.required],
      approvalStatus: ['APPROVED', Validators.required]
    });
  
  
    ngOnInit(): void {
      this.formDisable = this.userRole != 'HRBP';
  
      this.date = new Date();
      var momentVariable = moment(this.hrbpWithdrawal.createdDate, 'DD-MM-YYYY');
      var stringvalue = momentVariable.format('YYYY-MM-DD');
  
  
      this.hrbpWithdrawalForm.controls.resignationWithdrawalDate.patchValue(new Date(stringvalue));
      this.hrbpWithdrawalForm.controls.employeeRemarks.patchValue(this.hrbpWithdrawal.employeeRemarks);
      this.hrbpWithdrawalForm.controls.managerRemarks.patchValue(this.hrbpWithdrawal.managerRemarks);
      this.hrbpWithdrawalForm.controls.managerRemarks.patchValue(this.hrbpWithdrawal.gdcheadRemarks);
      this.hrbpWithdrawalForm.controls.hrbpRemarks.patchValue(this.hrbpWithdrawal.hrRemarks);
      this.approved = this.hrbpWithdrawal.approvalStatus == 'APPROVED'
    }
  
  
    submit = () => {
      this.hrbpWithdrawalForm.value.resignationWithdrawalDate = this.datePipe.transform(this.hrbpWithdrawalForm.value.resignationWithdrawlDate, 'dd-MM-yyyy');
      this.withdrawalService.hrbpWithdrawal(this.selectedUser, this.hrbpWithdrawalForm.value).subscribe(data => {
        this.approved = data.approvalStatus == 'COMPLETED'
        if (this.approved) {
          this.snackBar.open('HR Approval For Withdrawal Submitted Successfully', 'OK', {
            duration: 2000,
            verticalPosition: "top",
            horizontalPosition: "right"
          })
  
        }
        this.submitted.emit();
      }, error => {
        this.snackBar.open("Something Went Wrong", "RETRY", {
          duration: 3000,
          verticalPosition: "top",
          horizontalPosition: "right"
        });
  
      });
    }
  
    onClick = () => {
      this.hrbpWithdrawalForm.value.approvalStatus = 'REJECTED';
      this.hrbpWithdrawalForm.value.resignationWithdrawalDate = this.datePipe.transform(this.hrbpWithdrawalForm.value.resignationWithdrawlDate, 'dd-MM-yyyy');
      this.withdrawalService.hrbpWithdrawal(this.selectedUser, this.hrbpWithdrawalForm.value).subscribe(data => {
        this.approved = data.approvalStatus == 'REJECTED'
        if (this.approved) {
          this.snackBar.open('HRBP Rejection For Withdrawal Submitted Successfully', 'OK', {
            duration: 2000,
            verticalPosition: "top",
            horizontalPosition: "right"
          })
        }
        this.submitted.emit();
      }, error => {
        this.snackBar.open("Something Went Wrong", "RETRY", {
          duration: 3000,
          verticalPosition: "top",
          horizontalPosition: "right"
        });
  
      });
  
    }
  
  }
