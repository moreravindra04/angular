import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HrbpwithdrawalComponent } from './hrbpwithdrawal.component';

describe('HrbpwithdrawalComponent', () => {
  let component: HrbpwithdrawalComponent;
  let fixture: ComponentFixture<HrbpwithdrawalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HrbpwithdrawalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HrbpwithdrawalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
