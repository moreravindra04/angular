import { EventEmitterService } from './../services/event-emitter.service';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { UntypedFormBuilder, Validators, UntypedFormGroup } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ConfirmdialogComponent, ConfirmDialogModel } from '../confirmdialog/confirmdialog.component';
import { ActiveWithdrawal } from '../interface/activeWithdrawal';
import { ResignationWithdrawal } from '../interface/resignationWithdrawal';
import { User } from '../interface/user';
import { DataService } from '../services/data.service';
import { WithdrawalService } from '../services/withdrawal.service';

@Component({
  selector: 'app-resignationwithdrawal',
  templateUrl: './resignationwithdrawal.component.html',
  styleUrls: ['./resignationwithdrawal.component.css']
})
export class ResignationwithdrawalComponent implements OnInit {
 // resignationWithdrawal: ResignationWithdrawal;
 // approved: boolean;
  //user: User;
  withdrawn: boolean;
 // activeWithdrawal: boolean;
 // activeWithdrawalData: ResignationWithdrawal;
 // dataSource: { position: number; approvaltype: string; status: boolean; approvedby: string; }[];
 // result: any;

  resignationWithdrawalForm: UntypedFormGroup


  constructor(public dialogRef: MatDialogRef<ResignationwithdrawalComponent>, private fb: UntypedFormBuilder, private snackBar: MatSnackBar,private dialog: MatDialog, private withdrawalService: WithdrawalService, private eventEmitterService: EventEmitterService) { }
  


  ngOnInit(): void {
    //this.user = this.dataService.getUser();
    //this.withdrawn = this.resignationWithdrawal.approvalStatus== 'WITHDRAWAL_SUBMITTED';
    //this.resignationWithdrawalForm.controls.employeeRemarks.patchValue(this.resignationWithdrawal.employeeRemarks);
    //this.refresh();
    this.resignationWithdrawalForm = this.fb.group({
      employeeRemarks: [null, Validators.required]
    });

  }
  /*refresh() {
    this.withdrawalService.getActiveWithdrawal(this.user.userId).subscribe(data => {
      console.log(data);
      if (data.employeeRemarks == null) {
        this.activeWithdrawal = false;
        console.log("1");
      } else {
        this.activeWithdrawalData = data;
        console.log(data);
        this.activeWithdrawal = true;

        //add datasource here


      }
    });
  }*/



  withdraw = () => {
    // this.confirmDialog();
    //console.log(this.confirmDialog())
    this.withdrawalService.resignationWithdrawal(this.resignationWithdrawalForm.value).subscribe(data => {
    this.withdrawn = data.approvalStatus == 'PENDING_PM_WITHDRAWAL_CLEARANCE';
     // console.log(this.activeWithdrawal)
      if (this.withdrawn) {
        //if ((this.activeWithdrawal)) {
        //  console.log(this.activeWithdrawal)
          this.snackBar.open('Your Withdrawal Submitted Successfully', 'OK', {
            duration: 2000,
            verticalPosition: "top",
            horizontalPosition:"right"
          })

          //this.eventEmitterService.onWinthdrawalSubmit(); 
          this.dialogRef.close(true);
        //}       
      }
      //this.refresh();

    },
    error => {
      this.snackBar.open("Something Went Wrong", "RETRY", {
        duration: 3000,
        verticalPosition: "top",
      horizontalPosition:"right"
      });
    }
    )
  }
    confirmDialog(): void {
    
      //For Getting Confirmation Dialog Box
      const message = `Do you really want to withdraw?`;
      const dialogData = new ConfirmDialogModel("Confirmation", message);
      const dialogRef = this.dialog.open(ConfirmdialogComponent, {
        maxWidth: "400px",
        data: dialogData
      });
   
     dialogRef.afterClosed().subscribe(dialogResult => {
        //this.result = dialogResult;
        if(dialogResult){
          this.withdraw();
        }
            
      })
    }
}
