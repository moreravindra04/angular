import { EventEmitterService } from './services/event-emitter.service';
import { User } from './interface/user';
import { DataService } from './services/data.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = 'myseparation-portal';
  show = false;
  token: String;

  constructor(
    private dataService: DataService,
    private eventEmitterService: EventEmitterService
  ) {}

  ngOnInit() {
    if (this.eventEmitterService.subsVar == undefined) {
      this.eventEmitterService.subsVar =
        this.eventEmitterService.invokeShowUpdate.subscribe((name: string) => {
          this.token = this.dataService.getToken();
          this.show = this.token != null;
        });
    }
  }
}
