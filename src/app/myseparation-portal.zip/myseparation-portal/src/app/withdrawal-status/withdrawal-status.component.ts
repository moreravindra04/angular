import { DataService } from 'src/app/services/data.service';
import { Approvers } from './../interface/approvers';
import { User } from './../interface/user';
import { ResignationWithdrawal } from './../interface/resignationWithdrawal';
import { Status } from './../interface/status';
import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdrawal-status',
  templateUrl: './withdrawal-status.component.html',
  styleUrls: ['./withdrawal-status.component.css']
})
export class WithdrawalStatusComponent implements OnInit {

  @Input()
  activeWithdrawalData: ResignationWithdrawal;

  user: User;

  approvers: Approvers;

  dataSource: Status[];

  displayedColumns: String[] = ['approvaltype', 'status', 'approvedby'];

  constructor(private dataService: DataService) { }

  ngOnInit(): void {

    this.user = this.dataService.getUser();
    this.approvers = this.dataService.getApprovers();
    let lineManager = this.user.lineManager.firstName + " "+this.user.lineManager.lastName;

    this.dataSource = [
      { approvaltype: 'Project Manager Withdrawal:', status: (this.activeWithdrawalData.approvalStatus == 'PENDING_GDC_WITHDRAWAL_CLEARANCE') || (this.activeWithdrawalData.approvalStatus == 'PENDING_HR_WITHDRAWAL_CLEARANCE') || (this.activeWithdrawalData.approvalStatus == 'COMPLETED'), approvedby: lineManager},
      { approvaltype: 'GDC Withdrawal:', status: this.activeWithdrawalData.approvalStatus == 'PENDING_HR_WITHDRAWAL_CLEARANCE' || this.activeWithdrawalData.approvalStatus == 'COMPLETED' , approvedby: this.approvers.GdcApprover },
      { approvaltype: 'HRBP Withdrawal:', status: this.activeWithdrawalData.approvalStatus == 'COMPLETED', approvedby: this.approvers.HrbpApprover },
      
    ];

  }

}
