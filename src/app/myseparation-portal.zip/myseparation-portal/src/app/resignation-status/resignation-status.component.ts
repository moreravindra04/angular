import { ResignationwithdrawalComponent } from './../resignationwithdrawal/resignationwithdrawal.component';
import { MatDialog } from '@angular/material/dialog';
import { Approvers } from './../interface/approvers';
import { User } from './../interface/user';
import { DataService } from 'src/app/services/data.service';
import { ActiveResignation } from './../interface/activeResignation';
import { Status } from './../interface/status';
import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { ExitformComponent } from '../clearance/exitform/exitform.component';

@Component({
  selector: 'app-resignation-status',
  templateUrl: './resignation-status.component.html',
  styleUrls: ['./resignation-status.component.css']
})
export class ResignationStatusComponent implements OnInit {

  @Input() 
  activeResignationData: ActiveResignation;

  @Input()
  activeWithdrawal: Boolean

  @Output() submitted = new EventEmitter();
  
  user: User;

  approvers: Approvers;

  dataSource: Status[];  

  displayedColumns: String[] = ['approvaltype', 'status', 'approvedby'];

  approvalCompleted: Boolean;

  constructor(private dataService: DataService, private dialog: MatDialog) { }

  ngOnInit(): void {

    this.user = this.dataService.getUser();
    this.approvers = this.dataService.getApprovers();
    let lineManager = this.user.lineManager.firstName + " "+this.user.lineManager.lastName;
    this.approvalCompleted = this.activeResignationData.resignationStatus.hrClearance.clearanceDone;

    this.dataSource = [
      { approvaltype: 'Project Manager Clearance:' , status: this.activeResignationData.resignationStatus.managerClearance.clearanceDone, approvedby: lineManager},
      {approvaltype: 'GDC Clearance:', status: this.activeResignationData.resignationStatus.gdcClearance.clearanceDone, approvedby: this.approvers.GdcApprover},
      { approvaltype: 'IT Clearance:', status: this.activeResignationData.resignationStatus.itClearance.clearanceDone, approvedby: this.approvers.ItApprover},
     { approvaltype: 'Housing And Admin Clearance:', status: this.activeResignationData.resignationStatus.housingAndAdminClearance.clearanceDone, approvedby: this.approvers.HousingAndAdminApprover},
      { approvaltype: 'Finance Clearance:', status: this.activeResignationData.resignationStatus.financeClearance.clearanceDone, approvedby: this.approvers.FinanceApprover},
      { approvaltype: 'HRBP Clearance:', status: this.activeResignationData.resignationStatus.hrbpClearance.clearanceDone, approvedby: this.approvers.HrbpApprover},
      { approvaltype: 'HR Clearance:', status: this.activeResignationData.resignationStatus.hrClearance.clearanceDone, approvedby: this.approvers.HrApprover}
    
    ];
  }

  onPress() {
    const dialogRef = this.dialog.open(ResignationwithdrawalComponent, {
      width: '700px',
    })


    dialogRef.afterClosed().subscribe(result => {
      this.submitted.emit();
    });
  }


  
  onPressSave() {
    const dialogRef = this.dialog.open(ExitformComponent, {
      width: '700px',
    })

  }


}
