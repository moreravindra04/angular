import { EventEmitterService } from './../services/event-emitter.service';
import { DataService } from './../services/data.service';
import { UserAuthService } from './../services/user-auth.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private router: Router, private snackBar:MatSnackBar,private userAuthService : UserAuthService, private dataService: DataService, private eventEmitterService: EventEmitterService) { }

  ngOnInit(): void {
    this.userAuthService.logout().subscribe(data => {
      this.dataService.removeToken();
      this.dataService.removeUser();
      this.eventEmitterService.onLoginLogout(); 
      this.router.navigate(['login']).then(() =>{
        this.snackBar.open("You have successfully logged out","OK",{
          duration:2000,
          verticalPosition: "top",
          horizontalPosition:"right"
        });
      });
    });    
  }
}
