//for Local host
export const API_BASE_URL='http://localhost:5000/myseparation/api'
export const REDIRECT_URI='http://localhost:4200/login'
export const CLIENT_ID=