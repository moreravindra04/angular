import { DataService } from './data.service';
import { User } from './../interface/user';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { API_BASE_URL } from '../shared/var.constant';


@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  constructor(private http : HttpClient, private dataService: DataService) { }

  login(userName: String, password: String): Observable<any> {
    const headers = { 'Authorization': 'Basic '+ btoa(userName + ":" + password) };
    return this.http.post(API_BASE_URL + `/auth`, { }, {headers});
  }

  retrieveToken(code: String): Observable<any> {  
    const headers = { 'Authorization': 'Basic '+ btoa("dummyUser:" + code) };       
    return this.http.post<any>(API_BASE_URL + `/auth`, { }, {headers});        
  }

  getUser(): Observable<User> {
    const headers = this.dataService.getHeader();    
    return this.http.get<User>(API_BASE_URL + `/users/` + this.dataService.getUser().userId, {headers});
  }

  logout(): Observable<any> {
    const headers = this.dataService.getHeader();     
    return this.http.put(API_BASE_URL + `/logout`, {}, {headers});
  }

  checkCredentials() {
    return this.dataService.getToken() != null;
  }
}