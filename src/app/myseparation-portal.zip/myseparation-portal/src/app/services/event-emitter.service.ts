import { EventEmitter, Injectable } from '@angular/core';
import { Subscription } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EventEmitterService {

  invokeShowUpdate = new EventEmitter();    
  subsVar: Subscription;    
    
  constructor() { }    
    
  onLoginLogout() {    
    this.invokeShowUpdate.emit();    
  }
}
