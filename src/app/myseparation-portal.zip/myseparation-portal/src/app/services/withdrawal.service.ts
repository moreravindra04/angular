import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ActiveWithdrawal } from '../interface/activeWithdrawal';
import { ResignationWithdrawal } from '../interface/resignationWithdrawal';
import { API_BASE_URL } from '../shared/var.constant';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class WithdrawalService {

  constructor(private http : HttpClient, private dataService: DataService) { }

  resignationWithdrawal(resignationWithdrawal: ResignationWithdrawal): Observable<any> {
      const headers = this.dataService.getHeader();      
      return this.http.post<any>(API_BASE_URL + `/resignation/withdrawal/` + this.dataService.getUser().userId, resignationWithdrawal, {headers});
  }

  getWithdrawalsByStatus(status: String): Observable<ActiveWithdrawal[]> {
    const headers = this.dataService.getHeader();  
    return this.http.put<ActiveWithdrawal[]>(API_BASE_URL + `/resignation/withdrawal/search`, { "approvalStatus":status }, {headers});
  }

  getWithdrawalsByManagerAndStatus(status: String, managerId: String): Observable<ActiveWithdrawal[]> {
    const headers = this.dataService.getHeader();  
    return this.http.put<ActiveWithdrawal[]>(API_BASE_URL + `/resignation/withdrawal/search`, { "lineManagerId": managerId, "approvalStatus":status }, {headers});
  }

  getActiveWithdrawal(userId: String): Observable<ResignationWithdrawal> {
    const headers = this.dataService.getHeader();   
    return this.http.get<any>(API_BASE_URL + `/resignation/withdrawal/` + userId, {headers}).pipe(    
      catchError(this.handleError)
    );
  }

  pmWithdrawal(selectedUser: String, pmWithdrawal:ResignationWithdrawal): Observable<any> {
    const headers = this.dataService.getHeader();    
    return this.http.put<any>(API_BASE_URL + `/resignation/withdrawal/managerRemarks/` + selectedUser, pmWithdrawal, {headers});
  }

  gdcheadWithdrawal(selectedUser: String, gdcWithdrawal:ResignationWithdrawal): Observable<any> {
    const headers = this.dataService.getHeader();    
    return this.http.put<any>(API_BASE_URL + `/resignation/withdrawal/gdcRemarks/` + selectedUser, gdcWithdrawal, {headers});
  }


  hrbpWithdrawal(selectedUser: String, hrbpWithdrawal:ResignationWithdrawal): Observable<any> {
    const headers = this.dataService.getHeader();    
    return this.http.put<any>(API_BASE_URL + `/resignation/withdrawal/hrbpRemarks/` + selectedUser, hrbpWithdrawal, {headers});
  }

  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }    
    return of({} as ActiveWithdrawal);
  }
}
