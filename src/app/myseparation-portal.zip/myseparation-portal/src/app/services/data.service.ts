import { Approvers } from './../interface/approvers';
import { User } from './../interface/user';
import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  user: User;
  accessToken: String;
  approvers: Approvers;
  holidayDates:any;

  constructor() { }

  saveUserId = (userId: string) => {
    this.user = {} as User
    this.user.userId = userId;    
  }

  saveUser = (user: User) => {
    this.user = user;    
  }

  saveHolidayDates = (holidayDates: any) => {
    this.holidayDates = holidayDates;    
  }

  
  getholidayDates = () => {
    return this.holidayDates;
  }

  getUser = () => {
    return this.user;
  }

  saveApprovers = (approvers: Approvers) => {
    this.approvers = approvers;    
  }

  getApprovers = () => {
    return this.approvers;
  }

  removeUser = () => {
    this.user = null;
  }

  saveToken = (accessToken: String) => {
    this.accessToken = accessToken;    
  }

  getToken = () => {
    return this.accessToken;
  }

  removeToken = () => {
    this.accessToken = null;
  }

  getHeader = () =>{
    const headers = {        
            'X-Auth-UserId':''+this.getUser().userId,
            'X-Auth-Token':''+this.getToken()
         }
    return headers;
  }
}
