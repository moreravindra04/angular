import { HRClearance } from './../interface/hrClearance';
import { FinanceClearance } from './../interface/financeClearance';
import { LibraryClearance } from './../interface/libraryClearance';
import { ITClearance } from './../interface/itClearance';
import { ManagerClearance } from './../interface/managerClearance';
import { ActiveResignation } from './../interface/activeResignation';
import { Resignation } from './../interface/resignation';
import { DataService } from './data.service';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError } from 'rxjs/operators';
import { Clearance } from '../interface/clearance';
import { API_BASE_URL } from '../shared/var.constant';
import { Gdcclearance } from '../interface/gdcclearance';
import { HRBPClearance } from '../interface/hrbpClearance';
import { HousingandadminClearance } from '../interface/housingandadminClearance';

@Injectable({
  providedIn: 'root'
})
export class ResignationService {
  //api call to get holiday list for the year
  getCalendar() :Observable<any>  {
    const headers = this.dataService.getHeader();
    return this.http.get<any>(API_BASE_URL + `/resignation/calendardates` , {headers});
  }
  getReasons() :Observable<any>  {
    const headers = this.dataService.getHeader();
    return this.http.get<any>(API_BASE_URL + `/resignation/reasons` , {headers});
  }

  constructor(private http : HttpClient, private dataService: DataService) { }  
  
  exitForm(exitForm: string):Observable<any> {
    const headers = this.dataService.getHeader(); 
    return this.http.put<any>(API_BASE_URL + `/resignation/exitFrom/`+ this.dataService.getUser().userId, exitForm, {headers});
  }
  
  resign(resignation: Resignation): Observable<any> {
    const headers = this.dataService.getHeader();      
    return this.http.post<any>(API_BASE_URL + `/resignation/` + this.dataService.getUser().userId, resignation, {headers});
  }

  pmClearance(selectedUser: String, managerClearance: ManagerClearance): Observable<any> {
    const headers = this.dataService.getHeader();      
    return this.http.put<any>(API_BASE_URL + `/resignation/managerClearance/` + selectedUser, managerClearance, {headers});
  }

  gdcClearance(selectedUser: String, gdcClearance: Gdcclearance):Observable<any>{
    const headers = this.dataService.getHeader();     
    return this.http.put<any>(API_BASE_URL + `/resignation/gdcClearance/`+ selectedUser, gdcClearance, {headers})
  }

  itClearance(selectedUser: String, itClearance: ITClearance): Observable<any> {
    const headers = this.dataService.getHeader();     
    return this.http.put<any>(API_BASE_URL + `/resignation/itClearance/` + selectedUser, itClearance, {headers});
  }

  financeClearance(selectedUser: String, financeClearance: FinanceClearance): Observable<any> {
    const headers = this.dataService.getHeader();     
    return this.http.put<any>(API_BASE_URL + `/resignation/financeClearance/`+ selectedUser, financeClearance, {headers});
  }

  housingAndAdminClearance(selectedUser: String, housingandadminClearance: HousingandadminClearance): Observable<any> {
    const headers = this.dataService.getHeader();    
    return this.http.put<any>(API_BASE_URL + `/resignation/housingAndAdminClearance/`+ selectedUser, housingandadminClearance, {headers});
  }

  hrClearance(selectedUser: String, hrClearance: HRClearance): Observable<any> {
    const headers = this.dataService.getHeader();     
    return this.http.put<any>(API_BASE_URL + `/resignation/hrClearance/`+ selectedUser, hrClearance, {headers});
  }

  hrbpClearance(selectedUser: String, hrbpClearance: HRBPClearance): Observable<any> {
    const headers = this.dataService.getHeader();     
    return this.http.put<any>(API_BASE_URL + `/resignation/hrbpClearance/`+ selectedUser, hrbpClearance, {headers});
  } 
  getResignationsByManagerAndStatus(status: String, managerId: String): Observable<Clearance[]> {
    const headers = this.dataService.getHeader();  
    return this.http.put<Clearance[]>(API_BASE_URL + `/resignation/search`, {"lineManagerId": managerId, "clearanceStatus": status}, {headers});
  }

  getResignationsByStatus(status: String): Observable<Clearance[]> {
    const headers = this.dataService.getHeader();  
    return this.http.put<Clearance[]>(API_BASE_URL + `/resignation/search`, { "clearanceStatus": status}, {headers});
  }

  getActiveResignation(userId: String): Observable<ActiveResignation> {
    const headers = this.dataService.getHeader();    
    return this.http.get<ActiveResignation>(API_BASE_URL + `/resignation/` + userId, {headers}).pipe(    
      catchError(this.handleError)
    );
  }
  getApprovers() : Observable<any> {
    const headers = this.dataService.getHeader(); 
    return this.http.get<any>(API_BASE_URL + `/resignation/approverlist` , {headers});
  }
  
  
  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }    
    return of({} as ActiveResignation);
  }
}