export interface ResignationWithdrawal {
   
   employeeRemarks:String;
    managerRemarks:String;
    gdcheadRemarks:String,
    hrRemarks:String;
    approvalStatus:String;
    createdDate:Date;
}
