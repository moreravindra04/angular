export interface FinanceClearance{
    clearanceDone: boolean;
    id: number;
    approvalStatus: string;
    remarks: string;
}