export interface Status {
    approvaltype: string;
    status: boolean;
    approvedby:String;
}