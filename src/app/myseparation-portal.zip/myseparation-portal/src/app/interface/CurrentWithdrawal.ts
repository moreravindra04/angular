export interface CurrentWithdrawal{


 employeeRemarks:string;


 managerRemarks:string;

	
 hrRemarks:string;

 approvalStatus:string;

}