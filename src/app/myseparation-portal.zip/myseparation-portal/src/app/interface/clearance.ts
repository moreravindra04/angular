export interface Clearance {
    userId: string;
    name: string;
    email: string;
    lineManager: string;
    preferredLastWorkingDate: string;
    systemGeneratedLastWorkingDate: string;
    resignationStatus: string;
}    