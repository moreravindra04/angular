export interface Permission {
    id: number;
    permissionCode: string;
    permissionDescription: string;       
}