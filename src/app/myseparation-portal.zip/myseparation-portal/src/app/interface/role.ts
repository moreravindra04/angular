import { Permission } from './permission';
export interface Role {
    id: number,
    roleCode: string,
    roleDescription: string,
    permissions: Permission[]
}