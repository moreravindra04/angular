export interface ManagerClearance{
    clearanceDone: boolean;
    id: number;
    approvalStatus: string;
    actualLastWorkingDate: string;
    projectHandOverCompleted: boolean;
    projectAssetsSurrendered: boolean;
    appraisalCompleted: boolean;
    rehireAnEmployee: boolean;
    remarks: string;
}