export interface Gdcclearance {
    clearanceDone: boolean;
    id: number;
    approvalStatus: string;
    remarks: string;
}
