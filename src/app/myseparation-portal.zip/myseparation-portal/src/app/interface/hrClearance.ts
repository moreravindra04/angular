export interface HRClearance {
    clearanceDone: boolean;
    remarks: string;
    id: number;

    approvalStatus: string;
}