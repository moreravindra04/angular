export interface HRBPClearance {
    resignationReason: String;
    clearanceDone: boolean;
    id: number;
    approvalStatus: string;
    exitInterviewDone: boolean;
    exitInterviewDate: string;
    remarks: string;
}