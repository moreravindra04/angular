import { Role } from "./role";

export interface Linemanager {
    id: number,
    userId: string,
    firstName: string,
    lastName: string,
    designation: string,
    email: string,
    dateOfJoining: string,
    mobile: string,
    location: string,
    lineManager:Linemanager,
    roles: Role[] 
}
