export interface HousingandadminClearance {
    clearanceDone: boolean;
    id: number;
    approvalStatus: string;
    libraryBooksSurrendered: boolean;
    powerOfAttorney: boolean;
    canteenCleared: boolean;
    identityAndAccessCardSurrendered: boolean;
    parkingPassSurrendered: boolean;
    drawerKeysSurrendered: boolean;
    remarks: string;
}
