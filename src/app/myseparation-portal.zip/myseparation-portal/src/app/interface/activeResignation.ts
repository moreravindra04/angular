import { jsonData } from './jsonData';
import { Resignationstatus } from './resignationstatus';

export interface ActiveResignation {
    id: number;
    preferredLastWorkingDate: string;
    systemGeneratedLastWorkingDate: string;
    actualLastWorkingDate: string;
    reason: string;
    jsonData: string;
    resignationStatus: Resignationstatus;  
}