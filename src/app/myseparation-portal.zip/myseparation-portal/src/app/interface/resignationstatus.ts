import { FinanceClearance } from './financeClearance';
import { LibraryClearance } from './libraryClearance';
import { ITClearance } from './itClearance';
import { ManagerClearance } from './managerClearance';
import { HRClearance } from './hrClearance';
import { HrbpclearanceComponent } from '../clearance/hrbpclearance/hrbpclearance.component';
import { HousingandadminClearance } from './housingandadminClearance';
import { HRBPClearance } from './hrbpClearance';
export interface Resignationstatus {
    gdcClearance: any;
    id: number;
    overAllStatus: string;
    managerClearance: ManagerClearance;
    itClearance: ITClearance;
    //libraryClearance: LibraryClearance;
    housingAndAdminClearance: HousingandadminClearance;
    financeClearance: FinanceClearance;
    hrClearance: HRClearance;
    hrbpClearance:HRBPClearance;
}
