export interface ITClearance{
    clearanceDone: boolean;
    id: number;
    approvalStatus: string;
    laptopSurrendered: boolean;
    headphoneSurrendered: boolean;
    smartCardSurrendered: boolean;
    remarks: string;
}