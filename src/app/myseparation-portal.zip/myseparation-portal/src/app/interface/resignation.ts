export interface Resignation {   
    preferredLastWorkingDate :Date;
    systemGeneratedLastWorkingDate:Date;
    actualLastWorkingDate:Date;
    reason:string;
   

}
