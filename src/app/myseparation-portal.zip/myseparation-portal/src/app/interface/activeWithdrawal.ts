import { Resignationstatus } from "./resignationstatus";

export interface ActiveWithdrawal {
   
         userId:String ;
         name:String ;
        email:String ;
         lineManager:String ; 
         resignationCreatedDate:Date;
         actualLastWorkingDate:Date;
           withdrawalDate:Date;
    
        employeeRemarks:String ;
    
        overAllStatus:String; 
     
    
}
