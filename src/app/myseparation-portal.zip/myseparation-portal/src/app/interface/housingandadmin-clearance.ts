export interface HousingandadminClearance {
}
