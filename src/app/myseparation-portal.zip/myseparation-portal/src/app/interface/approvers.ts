export interface Approvers {
    GdcApprover: String;
    ItApprover:String;
    HousingAndAdminApprover:String;
    FinanceApprover: String;
    HrApprover: String;
    HrbpApprover: String;
}
