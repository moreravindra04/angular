export interface jsonData{

reason:string,
reason_betterSalary: boolean;
}