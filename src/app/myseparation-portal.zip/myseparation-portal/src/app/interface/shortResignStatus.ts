export interface ShortResignStatus {
    department: string;
    status: boolean;
}