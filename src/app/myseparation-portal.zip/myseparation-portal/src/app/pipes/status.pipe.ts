import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'status'
})
export class StatusPipe implements PipeTransform {

  transform(value: String, ...args: unknown[]): String {
    switch (value) {
      case "SUBMITTED": {
        return "Submitted";        
      }
      case "IN_PROGRESS": {
        return "In Progress";        
      }
      case "COMPLETED": {
        return "Completed";        
      }
      case "WITHDRAWAL_COMPLETED": {
        return "Withdrawal Completed";        
      }
      case "WITHDRAWAL_SUBMITTED": {
        return "Withdrawal Submitted";        
      }
      case "WITHDRAWAL_INPROGRESS": {
        return "Withdrawal In Progress";        
      }
      case "GDC_HEAD": {
        return "GDC HEAD";        
      }
      case "FINANCE_ADMIN": {
        return "FINANCE ADMIN";        
      }

      default: {
        return value;
      }
    }
  }

}
