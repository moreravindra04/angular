import { LogoutComponent } from './logout/logout.component';
import { LoginComponent } from './login/login.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ClearanceListComponent } from './clearance/clearance-list/clearance-list.component';
import { ResignationComponent } from './resignation/resignation.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import { ExitformComponent } from './clearance/exitform/exitform.component';
import {LocationStrategy, PathLocationStrategy} from '@angular/common';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'dashboard',
    component: DashboardComponent
  },
  {
    path: 'resignation',
    component: ResignationComponent
  },
  {
    path: 'clearance',
    component: ClearanceListComponent
  },
  {
    path: 'logout',
    component: LogoutComponent
  },
  {
    path: 'exitform',
    component: ExitformComponent
  },
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {path: '**', component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {})],
  exports: [RouterModule]
})
export class AppRoutingModule {}
