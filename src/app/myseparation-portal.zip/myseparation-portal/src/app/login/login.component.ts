import { environment } from './../../environments/environment';
import { CLIENT_ID, REDIRECT_URI, D_SERVER } from './../shared/var.constant';
import { DataService } from './../services/data.service';
import { UserAuthService } from './../services/user-auth.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userName: string;
  password: string;
  authProvider: string

  public isLoggedIn = false;
  public redirecting = false;

  constructor(private router: Router, private snackBar: MatSnackBar, private userAuthService: UserAuthService, private dataService: DataService) { }

  ngOnInit() {
    this.authProvider = environment.authProvider;
    //alert(this.authProvider);
    if (this.authProvider == 'D') {
      this.isLoggedIn = this.userAuthService.checkCredentials();
      //alert(this.isLoggedIn);
      let index = window.location.href.indexOf('code');
      //alert(index);
      if (!this.isLoggedIn && index != -1) {
        this.redirecting = true;
        this.userAuthService.retrieveToken(window.location.href.substring(index + 5)).subscribe(data => {
          this.dataService.saveUserId(data.userId);
          this.dataService.saveToken(data.access_token);
          this.router.navigate(['dashboard']).then(() => {
            this.snackBar.open("You Have Successfully Logged In", "OK", {
              duration: 3000,
              verticalPosition: "top",
              horizontalPosition:"right"
            })

          });;
        },
          error => {
            this.snackBar.open("Invalid Credentials", "OK", {
              duration: 3000,
              verticalPosition: "top",
              horizontalPosition:"right"
            });
          });
      }
    }
  }

  // Based on Auth provider it either go to D authetication system or application authetication system
  login = () => {
    if (this.authProvider == 'CUSTOM') {
      this.userAuthService.login(this.userName, this.password).subscribe(data => {
        this.dataService.saveUserId(this.userName);
        this.dataService.saveToken(data.access_token);
        this.router.navigate(['dashboard']).then(() => {
          this.snackBar.open("You Have Successfully Logged In", "OK", {
            duration: 2000,
            verticalPosition: "top",
            horizontalPosition:"right"
          })

        });
      },
        error => {
          this.snackBar.open("Oops!! Login Failed", "RETRY", {
            duration: 3000,
            verticalPosition: "top",
            horizontalPosition:"right"
          })

        });
    } else if (this.authProvider == 'DAS') {
      window.location.href = ;);
    }
  }
}
