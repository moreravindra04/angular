import { AppMaterialModule } from './app-material/app-material.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';

import { ResignationComponent } from './resignation/resignation.component';
import { PMClearanceComponent } from './clearance/pmclearance/pmclearance.component';
import { ITClearanceComponent } from './clearance/itclearance/itclearance.component';
import { FinanceClearanceComponent } from './clearance/finance-clearance/finance-clearance.component';
import { HRClearanceComponent } from './clearance/hrclearance/hrclearance.component';
import { MainNavigationComponent } from './main-navigation/main-navigation.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ClearanceListComponent } from './clearance/clearance-list/clearance-list.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { LogoutComponent } from './logout/logout.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { DatePipe } from '@angular/common';
import { ResignationsComponent } from './clearance/resignations/resignations.component';
import { WithdrawalComponent } from './clearance/withdrawal/withdrawal.component';

import { PmwithdrawalComponent } from './clearance/pmwithdrawal/pmwithdrawal.component';
import { ResignationwithdrawalComponent } from './resignationwithdrawal/resignationwithdrawal.component';
import { ConfirmdialogComponent } from './confirmdialog/confirmdialog.component';
import { WithdrawalStatusComponent } from './withdrawal-status/withdrawal-status.component';
import { ResignationStatusComponent } from './resignation-status/resignation-status.component';
import { StatusPipe } from './pipes/status.pipe';
import { ExitformComponent } from './clearance/exitform/exitform.component';
import { MatStepperModule } from '@angular/material/stepper';
import { GdcclearanceComponent } from './clearance/gdcclearance/gdcclearance.component';
import { HrbpclearanceComponent } from './clearance/hrbpclearance/hrbpclearance.component';
import { HousingandadminComponent } from './clearance/housingandadmin/housingandadmin.component';

import { GdcwithdrawalComponent } from './clearance/gdcwithdrawal/gdcwithdrawal.component';
import { HrbpwithdrawalComponent } from './clearance/hrbpwithdrawal/hrbpwithdrawal.component';

@NgModule({
    declarations: [
        AppComponent,
        LoginComponent,
        ResignationComponent,
        PMClearanceComponent,
        ITClearanceComponent,
        FinanceClearanceComponent,
        HRClearanceComponent,
        MainNavigationComponent,
        DashboardComponent,
        ClearanceListComponent,
        PageNotFoundComponent,
        LogoutComponent,
        ResignationsComponent,
        WithdrawalComponent,
        PmwithdrawalComponent,
        ResignationwithdrawalComponent,
        ConfirmdialogComponent,
        WithdrawalStatusComponent,
        ResignationStatusComponent,
        StatusPipe,
        ExitformComponent,
        StatusPipe,
        HousingandadminComponent,
        HrbpclearanceComponent,
        GdcclearanceComponent,
        GdcwithdrawalComponent, HrbpwithdrawalComponent
    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        BrowserAnimationsModule,
        AppMaterialModule,
        HttpClientModule,
        FormsModule,
        ReactiveFormsModule,
        MatStepperModule,
    ],
    providers: [DatePipe],
    bootstrap: [AppComponent]
})
export class AppModule { }
