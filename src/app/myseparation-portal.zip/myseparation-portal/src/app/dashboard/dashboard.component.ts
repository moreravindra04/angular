import { Approvers } from './../interface/approvers';
import { ResignationService } from './../services/resignation.service';
import { EventEmitterService } from './../services/event-emitter.service';
import { DataService } from './../services/data.service';
import { UserAuthService } from './../services/user-auth.service';
import { User } from './../interface/user';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  user: User;
  approvers: Approvers;

  constructor(private userAuthService:UserAuthService, private dataService: DataService, private eventEmitterService: EventEmitterService, private resignationService: ResignationService) { }

  ngOnInit(): void {
    this.userAuthService.getUser().subscribe(data => {
      this.user = data;
      this.dataService.saveUser(data);
      this.eventEmitterService.onLoginLogout(); 
    });

    this.resignationService.getApprovers().subscribe(data=> {
   
      this.approvers = {} as Approvers;
     
      
      this.approvers.GdcApprover = data[0].firstName +" "+ data[0].lastName ;
      this.approvers.ItApprover= data[1].firstName +" "+ data[1].lastName ;
      this.approvers.HousingAndAdminApprover = data[2].firstName +" "+ data[2].lastName ;
      this.approvers.HrbpApprover = data[4].firstName +" "+ data[4].lastName ;
      this.approvers.FinanceApprover = data[3].firstName +" "+ data[3].lastName ;
      this.approvers.HrApprover = data[5].firstName +" "+ data[5].lastName ;
      

      this.dataService.saveApprovers(this.approvers);
    })
    this.resignationService.getCalendar().subscribe(data => {
      this.dataService.saveHolidayDates(data);
     //console.log(this.dates);
    });


  }
}
